
# Tableau Dashboard Guide

## CALCULATED FIELDS

### Monthly Fee
CASE [Account_Type]
WHEN "Select Account" THEN 0
WHEN "Select Silver Account" THEN 8
WHEN "Select Platinum Account" THEN 18
WHEN "Primer Account" THEN 31.99
WHEN "Student Account" THEN 0 END

### APR (Select Account Only)
IF [Account_Type]="Select Account" THEN [Overdraft_Amount]*0.3949 ELSE 0 END

### Net Customer Cost
([Overdraft_Fee] + [APR_Charge] + [Monthly_Fee]) - [Refund_Amount]

### Top 10 Overdraft Users (LOD)
{ FIXED [Customer_ID] : SUM([Overdraft_Amount]) }

Filter:
INDEX() <= 10

## DASHBOARD LIST
1. KPI Summary
2. Overdraft & Refund Trends
3. Customer Heatmap
4. Account Type Revenue
5. Top 10 Overdraft Users
6. Net Customer Cost Breakdown
