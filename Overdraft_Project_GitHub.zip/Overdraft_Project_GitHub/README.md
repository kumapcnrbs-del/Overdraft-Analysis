
# Overdraft Charges Analysis – Tableau Project

## 📌 Overview
This project analyzes overdraft behavior, customer risk, refund patterns, account-type profitability, and top 10 overdraft users.  
Includes:
- 10,000-row realistic dataset  
- Tableau dashboard blueprint  
- BRD document  
- Calculation logic & LOD expressions  

## 📂 Repository Structure
```
Overdraft_Project_GitHub/
│── data/
│   └── overdraft_10000rows.csv
│── docs/
│   └── BRD_Summary.txt
│   └── Tableau_Dashboard_Guide.md
│── README.md
```

## 🧠 Tableau Features
- Top 10 overdraft users using LOD + Rank  
- Customer behavior heatmap  
- Monthly fee, APR, refund & net cost calculations  
- Account type segmentation & profitability  
- Executive KPI dashboard  

## 🛠 Technologies
- Tableau
- Python (for dataset generation)
- Excel/CSV dataset

## 📈 Dashboards to Build in Tableau
1. Executive Summary  
2. Overdraft Trends  
3. Customer Behavior  
4. Account Type Impact  
5. Top 10 Overdraft Users  
6. Net Customer Cost

## 🚀 How to Use
1. Import `/data/overdraft_10000rows.csv` into Tableau  
2. Copy calculated fields from `/docs/Tableau_Dashboard_Guide.md`  
3. Build dashboards using the visualization guide  
4. Publish to Tableau Public OR push repo to GitHub

## 🔗 Publish to GitHub Instructions
```
git init
git add .
git commit -m "Initial commit - Overdraft Charges Tableau Project"
git branch -M main
git remote add origin https://github.com/yourusername/overdraft-tableau-analysis.git
git push -u origin main
```

## 📄 License
MIT License
